import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserVotingComponent } from './user-voting.component';

describe('UserVotingComponent', () => {
  let component: UserVotingComponent;
  let fixture: ComponentFixture<UserVotingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserVotingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserVotingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
