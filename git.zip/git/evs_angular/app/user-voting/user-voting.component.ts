import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ElectionParticipants } from '../election-participants';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-voting',
  templateUrl: './user-voting.component.html',
  styleUrls: ['./user-voting.component.css']
})
export class UserVotingComponent implements OnInit {
  voter:any;
  list:ElectionParticipants[]|any=[];
  checkele:any;
  constructor(private router:Router, private userService:UserServiceService, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    this.adminService.getListParticipant(this.adminService.election).subscribe(data=>{this.list=data});
    this.userService.getVoter(this.userService.voter).subscribe(data=>{this.voter=data});
    if(this.voter.status==='true'){
      this.router.navigate(['/thank']);
    }
  }

  vote(element:any){
    this.list.forEach((value:any) => {
      if(value===element){
        let resp= this.userService.updateVotes(value);
        resp.subscribe(data=>{this.checkele=data});
        let rep=this.userService.afterVote(this.userService.voter);
        rep.subscribe(data=>{this.checkele=data});
        this.router.navigate(['/thank']);
      }
    });
  }
}
