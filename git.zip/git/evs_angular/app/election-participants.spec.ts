import { ElectionParticipants } from './election-participants';

describe('ElectionParticipants', () => {
  it('should create an instance', () => {
    expect(new ElectionParticipants()).toBeTruthy();
  });
});
