import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ConstituencyService } from '../constituency.service';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent implements OnInit {
  user:User | any=new User();
  constructor(private router: Router,private userService:UserServiceService, private constService:ConstituencyService) {}

  ngOnInit(): void {
    if(this.userService.user!=undefined){
      this.router.navigate(["/userHome"]);
    }
  }
  consts:string[]=this.constService.getConsts();
  onSubmit(){
    let resp=this.userService.save(this.user);
    resp.subscribe(data=>{this.userService.user=data});
    this.goToSqa();
  }

  goToSqa(){
    this.router.navigate(['/sqa']);
  }
}
