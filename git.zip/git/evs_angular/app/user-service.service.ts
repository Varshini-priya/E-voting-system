import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './user';
import { SecurityQA } from './SecurityQA';
import { Voter } from './voter';
import { VoterLogin } from './voter-login';
import { Participant } from './participant';

@Injectable({
  providedIn: 'root'
})

export class UserServiceService {
  constructor(private http: HttpClient) {
  }
  public user:User | any;
  public voter:Voter=new Voter();

  //User register method
  public save(user:User){
    return this.http.post("http://localhost:8909/evs/addUsers", user);
  }

  //Get user by phone number
  public getUserByPno(user:User){
    return this.http.post("http://localhost:8909/evs/getUser", user);
  }

  //Adding a seciruty question and answer
  public sqa(sqa:SecurityQA){
    return this.http.post("http://localhost:8909/evs/sqa", sqa);
  }

  //User login method
  public login(user:User){
    return this.http.post("http://localhost:8909/evs/login", user)
  }

  //Check voter credentials
  public checkVoter(vl:VoterLogin){
    return this.http.post("http://localhost:8909/evs/admin/voter/check", vl);
  }

  //Set status of single voter
  public afterVote(voter:Voter){
    return this.http.post("http://localhost:8909/evs/admin/voter/update", voter);
  }

  //Get security question and answer
  public getsqa(user:User){
    return this.http.post("http://localhost:8909/evs/getSqa", user);
  }

  //change Password
  public changePass(user:User){
    return this.http.post("http://localhost:8909/evs/changepass", user);
  }

  //Update votes
  public updateVotes(p:Participant){
    return this.http.post("http://localhost:8909/evs/admin/participant/update", p);
  }

  //Get voter details
  public getVoter(v:Voter){
    return this.http.post("http://localhost:8909/evs/admin/get/voter", v);
  }
}
