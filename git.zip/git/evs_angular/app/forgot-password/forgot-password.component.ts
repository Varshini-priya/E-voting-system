import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  user:User=new User();
  user1:any;
  sqa:any;
  ans:any;
  value:string='false';
  constructor(private router:Router, private userService:UserServiceService) { }

  ngOnInit(): void {
    this.value='false';
  }

  enter(){
    this.userService.getUserByPno(this.user).subscribe(data=>{this.user1=data});
    if(this.user1===null||!this.user1){
      this.error();
    }
    else{
      this.qa();
    }
  }

  qa(){
    this.userService.user=this.user1;
    this.userService.getsqa(this.userService.user).subscribe(data=>{this.sqa=data});
    this.value='true';
  }

  error(){
    alert("No phone number exists!!");
    this.router.navigate(['/forgotpass']);
  }

  check(){
    if(this.ans===this.sqa.answer){
      this.router.navigate(['/changepass']);
    }
    else{
      alert("Wrong answer!!");
    }
  }
}
