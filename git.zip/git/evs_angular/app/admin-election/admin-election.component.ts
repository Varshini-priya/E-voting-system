import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ConstituencyService } from '../constituency.service';

@Component({
  selector: 'app-admin-election',
  templateUrl: './admin-election.component.html',
  styleUrls: ['./admin-election.component.css']
})
export class AdminElectionComponent implements OnInit {

  constructor(private router:Router, private adminService:AdminServiceService, private constService:ConstituencyService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
  }

}
