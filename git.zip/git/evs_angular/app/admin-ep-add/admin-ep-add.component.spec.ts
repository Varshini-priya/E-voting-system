import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminEpAddComponent } from './admin-ep-add.component';

describe('AdminEpAddComponent', () => {
  let component: AdminEpAddComponent;
  let fixture: ComponentFixture<AdminEpAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminEpAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminEpAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
