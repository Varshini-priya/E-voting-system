import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ElectionParticipants } from '../election-participants';

@Component({
  selector: 'app-admin-ep-add',
  templateUrl: './admin-ep-add.component.html',
  styleUrls: ['./admin-ep-add.component.css']
})
export class AdminEpAddComponent implements OnInit {
  li:any;
  checkele:any;
  value:boolean=false;
  ep:ElectionParticipants=new ElectionParticipants();
  constituency:string='';
  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
    let resp=this.adminService.getListParticipant(this.adminService.ep.election);
    resp.subscribe(data=>{this.li=data});
    /*if(!this.li||this.li===null){
      this.value=true;
    }*/
  }

  

  add(element:any){
    this.li.forEach((value:any)=>{
      if(value===element){
        this.adminService.ep.participants=element;
        this.ep=this.adminService.ep;
        this.adminService.addParticipant(this.ep).subscribe(data=>{this.checkele=data});
        this.li=this.li.filter((item:any)=>item!=value);
        alert("Participant added to election!!");
        this.router.navigate(['ep/add']);
      }
    })

  }

  empty(){
    this.adminService.deleteElection(this.adminService.election).subscribe(data=>{this.checkele=data});
    this.router.navigate(['election/list']);
  }

  continue(){
    this.router.navigate(['election/list']);
  }
}
