import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ElectionParticipants } from '../election-participants';

@Component({
  selector: 'app-user-results',
  templateUrl: './user-results.component.html',
  styleUrls: ['./user-results.component.css']
})
export class UserResultsComponent implements OnInit {
  list:ElectionParticipants[]|any=[];
  constructor(private router:Router, private adminService:AdminServiceService){ }

  ngOnInit(): void {
    let resp=this.adminService.getEp(this.adminService.election);
    resp.subscribe(data=>{this.list=data});
  }

  
}
