import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-home',
  templateUrl: './user-home.component.html',
  styleUrls: ['./user-home.component.css']
})
export class UserHomeComponent implements OnInit {

  constructor(private router:Router, private userService:UserServiceService) { }

  ngOnInit(): void {
    if (this.userService.user===undefined||this.userService.user===null){
      this.router.navigate(["/login"]);
    }
  }

  logout(){
    this.userService.user=undefined;
    this.router.navigate([""]);
  }
}
