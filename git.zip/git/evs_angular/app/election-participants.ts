import { Election } from "./election";
import { Participant } from "./participant";

export class ElectionParticipants {
    constructor(){}
    id:number|undefined;
    noOfVote:number=0;
    election:Election=new Election();
    participants:Participant=new Participant();
}
