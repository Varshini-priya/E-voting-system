export class Voter {
    constructor(){}
    
    voterId:number=0;
    name:string|undefined;
    phoneNo:number|undefined;
    status:string="false";
}
