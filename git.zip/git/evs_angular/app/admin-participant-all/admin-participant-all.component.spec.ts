import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminParticipantAllComponent } from './admin-participant-all.component';

describe('AdminParticipantAllComponent', () => {
  let component: AdminParticipantAllComponent;
  let fixture: ComponentFixture<AdminParticipantAllComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminParticipantAllComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminParticipantAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
