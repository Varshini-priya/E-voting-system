import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Participant } from '../participant';

@Component({
  selector: 'app-admin-participant-all',
  templateUrl: './admin-participant-all.component.html',
  styleUrls: ['./admin-participant-all.component.css']
})
export class AdminParticipantAllComponent implements OnInit {
  li:Participant[]|any=[];
  participant:any;
  value:boolean=true;
  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
    let resp=this.adminService.getParticipants(this.adminService.participant.party);
    resp.subscribe(data=>{this.li=data});
  }

  delete(element:any){
    this.li.forEach((value:any)=>{
      if(value===element){
        let rep=this.adminService.deleteParticipant(value);
        rep.subscribe(data=>{this.participant=data});
        alert("Participant deleted!!");
        let resp=this.adminService.getParticipants(this.adminService.participant.party);
        resp.subscribe(data=>{this.li=data});
        this.router.navigate(['/participant/get']);
      }
    });
  }

  redirect1(){
    this.router.navigate(['/participant/add']);
  }

  redirect2(){
    this.router.navigate(['/participant/party']);
  }

}
