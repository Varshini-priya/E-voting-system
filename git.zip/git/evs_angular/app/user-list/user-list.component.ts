import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  users:User[] | undefined;
  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
      let response=this.adminService.getAll();
      response.subscribe(data=>{
      this.users=data;
      });
  }

}
