import { SecurityQA } from './SecurityQA';

describe('SecurityQA', () => {
  it('should create an instance', () => {
    expect(new SecurityQA()).toBeTruthy();
  });
});
