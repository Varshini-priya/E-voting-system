import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminElectionScheduleComponent } from './admin-election-schedule.component';

describe('AdminElectionScheduleComponent', () => {
  let component: AdminElectionScheduleComponent;
  let fixture: ComponentFixture<AdminElectionScheduleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminElectionScheduleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminElectionScheduleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
