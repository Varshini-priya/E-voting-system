import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ConstituencyService } from '../constituency.service';
import { Election } from '../election';

@Component({
  selector: 'app-admin-election-schedule',
  templateUrl: './admin-election-schedule.component.html',
  styleUrls: ['./admin-election-schedule.component.css']
})
export class AdminElectionScheduleComponent implements OnInit {
  election:Election=new Election();
  checkEle:Election | any=new Election();
  constructor(private router:Router, private adminService:AdminServiceService, private constService:ConstituencyService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
  }
  consts:string[]=this.constService.constituencies;
  check(){
    this.adminService.getElectionByDate(this.election).subscribe(data=>{this.checkEle=data});
    if (this.checkEle===null||!this.checkEle){
      this.schedule();
    }
    else{
      alert("Election is already scheduled!!");
    }
  }

  schedule(){
    this.adminService.addElection(this.election).subscribe(data=>{this.checkEle=data});
    alert("Election Scheduled!!");
    this.router.navigate(['/election/list']);
  }

}
