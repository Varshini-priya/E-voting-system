import { Participant } from './participant';

describe('Participant', () => {
  it('should create an instance', () => {
    expect(new Participant()).toBeTruthy();
  });
});
