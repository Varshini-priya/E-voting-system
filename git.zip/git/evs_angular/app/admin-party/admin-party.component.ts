import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ConstituencyService } from '../constituency.service';
import { Party } from '../party';

@Component({
  selector: 'app-admin-party',
  templateUrl: './admin-party.component.html',
  styleUrls: ['./admin-party.component.css']
})
export class AdminPartyComponent implements OnInit {
  constructor(private router:Router, private adminService:AdminServiceService, private constService:ConstituencyService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
  }

  message:string=this.adminService.message;

  redirect(){
    this.adminService.message='';
    this.router.navigate(['/party/all']);
  }

  redirect1(){
    this.adminService.message='';
    this.router.navigate(['/participant/party']);
  }
}
