import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminVoterComponent } from './admin-voter.component';

describe('AdminVoterComponent', () => {
  let component: AdminVoterComponent;
  let fixture: ComponentFixture<AdminVoterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminVoterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminVoterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
