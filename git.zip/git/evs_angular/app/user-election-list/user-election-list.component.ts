import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { UserServiceService } from '../user-service.service';
import { DatePipe } from '@angular/common';
import { Election } from '../election';

@Component({
  selector: 'app-user-election-list',
  templateUrl: './user-election-list.component.html',
  styleUrls: ['./user-election-list.component.css']
})
export class UserElectionListComponent implements OnInit {
  list:Election[]=[];
  checkele:any;
  date:Date=new Date(Date.now());
  election:Election=new Election();
  constructor(private router:Router, private adminService:AdminServiceService, private userService:UserServiceService) { }

  ngOnInit(): void {
    if (this.userService.user===undefined||this.userService.user===null){
      this.router.navigate(["/login"]);
    }
    this.adminService.getElections().subscribe(data=>{this.list=data});
  }

  select(element:any){
    this.list.forEach((value:Election|any) => {
      if(value===element){
        this.adminService.election=value;
        this.election=value;
        if(this.date!==this.election.dateTime){
          this.router.navigate(["/voter/login"]);
        }
        else{
          alert("This election is not scheduled for today!!");
          this.router.navigate(["user/election'"]);
        }
      }
    });
  }
}
