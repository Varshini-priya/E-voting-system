import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-election',
  templateUrl: './user-election.component.html',
  styleUrls: ['./user-election.component.css']
})
export class UserElectionComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
