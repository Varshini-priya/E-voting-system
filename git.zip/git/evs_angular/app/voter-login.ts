export class VoterLogin {
    constructor(){}

    voterId:number=0;
    userId:number|undefined;
    password:string|undefined;
}
