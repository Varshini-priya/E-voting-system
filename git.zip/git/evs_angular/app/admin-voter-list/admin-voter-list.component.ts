import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Voter } from '../voter';

@Component({
  selector: 'app-admin-voter-list',
  templateUrl: './admin-voter-list.component.html',
  styleUrls: ['./admin-voter-list.component.css']
})
export class AdminVoterListComponent implements OnInit {
  list:Voter[]|any=[];
  voter:any;
  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
    let resp=this.adminService.getVoters();
    resp.subscribe(data=>{this.list=data});
  }

  delete(element:any){
    this.list.forEach((value:any)=>{
      if(value==element){
        this.adminService.deleteVoter(value).subscribe(data=>{this.voter=data});
        alert("Voter deleted!!");
        let resp=this.adminService.getVoters();
        resp.subscribe(data=>{this.list=data});
        this.router.navigate(['/voter/list']);
      }
    });
  }

  add(){
    this.router.navigate(['/voter/add']);
  }
}
