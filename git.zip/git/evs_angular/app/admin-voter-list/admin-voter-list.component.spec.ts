import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminVoterListComponent } from './admin-voter-list.component';

describe('AdminVoterListComponent', () => {
  let component: AdminVoterListComponent;
  let fixture: ComponentFixture<AdminVoterListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminVoterListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminVoterListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
