import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.css']
})
export class AdminLoginComponent implements OnInit {

  admin:Admin=new Admin();
  pass='password';
  show = false;
  public showPasswordOnPress: boolean =false;

  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin!=undefined){
      this.router.navigate(["/adminHome"]);
    }
  }

  login(){
    let resp=this.adminService.adminLogin(this.admin);
    resp.subscribe(data=>{this.adminService.admin=data});
    if (this.adminService.admin===null || this.adminService.admin===undefined){
      alert("please check your credentials!!");
    }else{
      this.goToAdminHome();
    }
  }

  goToAdminHome(){
    this.router.navigate(['/adminHome']);
  }

  onClick() {
    if (this.pass === 'password') {
      this.pass = 'text';
      this.show = true;
    } else {
      this.pass = 'password';
      this.show = false;
    }
  }

}
