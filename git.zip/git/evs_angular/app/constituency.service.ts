import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConstituencyService {
  public constituencies:string[]=[
    "Chennai",
    "Madurai",
    "Coimbatore",
    "Tripur",
    "Velore"
  ];
  constructor() { }

  getConsts(){
    return this.constituencies;
  }
}
