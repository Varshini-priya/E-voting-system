import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sqa-list',
  templateUrl: './sqa-list.component.html',
  styleUrls: ['./sqa-list.component.css']
})
export class SqaListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
