import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SqaListComponent } from './sqa-list.component';

describe('SqaListComponent', () => {
  let component: SqaListComponent;
  let fixture: ComponentFixture<SqaListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SqaListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SqaListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
