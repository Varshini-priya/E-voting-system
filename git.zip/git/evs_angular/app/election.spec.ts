import { Election } from './election';

describe('Election', () => {
  it('should create an instance', () => {
    expect(new Election()).toBeTruthy();
  });
});
