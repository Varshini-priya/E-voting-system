import { Party } from "./party";

export class Participant {
    constructor(){}
    participantId:number|undefined;
    participantName:String|undefined;
    party:Party=new Party();
}
