import { User } from "./user";

export class SecurityQA {
    constructor(){

    }
    sqaId:number | undefined;
    question:string | undefined;
    answer:string | undefined;
    user:User|undefined;
}
