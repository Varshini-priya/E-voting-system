import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Admin } from './admin';
import { Election } from './election';
import { ElectionParticipants } from './election-participants';
import { Participant } from './participant';
import { Party } from './party';
import { User } from './user';
import { Voter } from './voter';

@Injectable({
  providedIn: 'root'
})
export class AdminServiceService {

  constructor(private http:HttpClient) { }

  public admin:Admin | any;
  public election:Election|any;
  public message:any; public error:any;
  public participant:Participant=new Participant();
  public ep:ElectionParticipants=new ElectionParticipants();

  //Admin login
  public adminLogin(ad:Admin){
    return this.http.post("http://localhost:8909/evs/admin/login", ad);
  }

  //Get all user's details
  public getAll(): Observable<User[]> {
    return this.http.get<User[]>("http://localhost:8909/evs/admin/users");
  }

  //Insert party details
  public addParty(party:Party){
    return this.http.post("http://localhost:8909/evs/admin/party/add", party);
  }

  //Get party details
  public getParty(party:Party){
    return this.http.post("http://localhost:8909/evs/admin/party/get", party);
  }

  //Get all party details
  public getAllParties():Observable<Party[]>{
    return this.http.get<Party[]>("http://localhost:8909/evs/admin/party/getAll");
  }

  //Delete party details
  public deleteParty(id:any){
    return this.http.post("http://localhost:8909/evs/admin/party/delete", id);
  }

  //Get participant through name
  public getParticipantByName(participant:Participant){
    return this.http.post("http://localhost:8909/evs/admin/participant/get", participant);
  }

  //Get participants through party
  public getParticipants(party:Party):Observable<Participant[]>{
    return this.http.post<Participant[]>("http://localhost:8909/evs/admin/participant/get/party", party);
  }

  //Save participants 
  public saveParticipant(participant:Participant){
    return this.http.post("http://localhost:8909/evs/admin/participant/add", participant);
  }

  //Delete participant
  public deleteParticipant(participant:Participant){
    return this.http.post("http://localhost:8909/evs/admin/participant/delete", participant);
  }

  //Add Voter
  public addVoter(voter:Voter){
    return this.http.post("http://localhost:8909/evs/admin/voter/add", voter);
  }

  //Get all Voters
  public getVoters():Observable<Voter>{
    return this.http.get<Voter>("http://localhost:8909/evs/admin/voter/get");
  }

  //Get voter by voterId
  public getVoterByVoterId(voterId:number){
    return this.http.post("http://localhost:8909/evs/admin/voter/getOne", voterId);
  }

  //Set status to false
  public updateVoterList(){
    this.http.get("http://localhost:8909/evs/admin/voter/status");
  }

  //delete voter
  public deleteVoter(voter:Voter){
    return this.http.post("http://localhost:8909/evs/admin/voter/delete", voter);
  }

  //Create election
  public addElection(e:Election){
    return this.http.post("http://localhost:8909/evs/admin/election/add", e);
  }

  //Get election by date
  public getElectionByDate(e:Election){
    return this.http.post("http://localhost:8909/evs/admin/election/get", e);
  }

  //Get election by id
  public getElectionById(e:Election){
    return this.http.post("http://localhost:8909/evs/admin/election/id", e);
  }

  //Get all elections
  public getElections():Observable<Election[]>{
    return this.http.get<Election[]>("http://localhost:8909/evs/admin/election/list");
  }

  //Delete election
  public deleteElection(e:Election){
    return this.http.post("http://localhost:8909/evs/admin/election/delete", e);
  }

  //Add participants in election
  public addParticipant(ep:ElectionParticipants){
    return this.http.post("http://localhost:8909/evs/admin/ep/add", ep);
  }

  //Get participant by constituency
  public getListParticipant(election:Election):Observable<Participant[]>{
    return this.http.post<Participant[]>("http://localhost:8909/evs/admin/participant/ep", election);
  }

  //Get election Participants
  public getEp(election:Election):Observable<ElectionParticipants[]>{
    return this.http.post<ElectionParticipants[]>("http://localhost:8909/evs/admin/eps/get", election);
  }
}
