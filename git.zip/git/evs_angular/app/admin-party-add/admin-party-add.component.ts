import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ConstituencyService } from '../constituency.service';
import { Party } from '../party';

@Component({
  selector: 'app-admin-party-add',
  templateUrl: './admin-party-add.component.html',
  styleUrls: ['./admin-party-add.component.css']
})
export class AdminPartyAddComponent implements OnInit {
  party:Party=new Party();
  partyCheck :any;
  error:string='';
  constructor(private router:Router, private adminService:AdminServiceService, private constService:ConstituencyService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
  }

  consts:string[]=this.constService.getConsts();

  check(){
    let resp=this.adminService.getParty(this.party);
    resp.subscribe(data=>{this.partyCheck=data});
    if(this.partyCheck===null){
      this.add();
    }
    else if (this.partyCheck!==null){
      this.errors();
    }
  }

  add(){
    let resp=this.adminService.addParty(this.party);
    resp.subscribe(data=>{this.partyCheck=data});
    alert("Party details added!!")
    this.router.navigate(['/party']);
  }

  errors(){
      this.error="Party already exits!!";
      this.router.navigate(['/party/add']);
  }
}
