import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SqaFormComponent } from './sqa-form.component';

describe('SqaFormComponent', () => {
  let component: SqaFormComponent;
  let fixture: ComponentFixture<SqaFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SqaFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SqaFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
