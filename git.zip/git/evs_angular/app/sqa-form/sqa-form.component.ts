import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SecurityQA } from '../SecurityQA';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-sqa-form',
  templateUrl: './sqa-form.component.html',
  styleUrls: ['./sqa-form.component.css']
})
export class SqaFormComponent implements OnInit {
  sqa : SecurityQA=new SecurityQA();
  constructor(private router:Router, private userService:UserServiceService) { }

  ngOnInit(): void {
  }
  
  view(){
    let resp=this.userService.sqa(this.sqa);
    resp.subscribe(result=>this.goToConfimation());
  }

  goToConfimation(){
    this.router.navigate(['/confirm']);
  }
}
