import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-confirmation',
  templateUrl: './user-confirmation.component.html',
  styleUrls: ['./user-confirmation.component.css']
})
export class UserConfirmationComponent implements OnInit {

  constructor(private router: Router,private userService:UserServiceService) { }

  ngOnInit(): void {
  }

  user=this.userService.user;

  confirm(){
    this.router.navigate(['/login']);
  }
}
