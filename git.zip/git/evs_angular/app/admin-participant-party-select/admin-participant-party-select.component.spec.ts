import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminParticipantPartySelectComponent } from './admin-participant-party-select.component';

describe('AdminParticipantPartySelectComponent', () => {
  let component: AdminParticipantPartySelectComponent;
  let fixture: ComponentFixture<AdminParticipantPartySelectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminParticipantPartySelectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminParticipantPartySelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
