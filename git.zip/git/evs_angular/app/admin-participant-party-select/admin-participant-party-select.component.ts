import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Participant } from '../participant';
import { Party } from '../party';

@Component({
  selector: 'app-admin-participant-party-select',
  templateUrl: './admin-participant-party-select.component.html',
  styleUrls: ['./admin-participant-party-select.component.css']
})
export class AdminParticipantPartySelectComponent implements OnInit {
  list:Party[]=[];
  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
    let resp=this.adminService.getAllParties();
    resp.subscribe(data=>{this.list=data});
  }

  select(element:any){
    this.list.forEach((value:any)=>{
      if(value==element){
        this.adminService.participant.party=value;
        this.router.navigate(['/participant/get']);
      }
    });
  }

}
