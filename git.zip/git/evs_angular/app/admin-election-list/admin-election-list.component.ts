import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { ConstituencyService } from '../constituency.service';

@Component({
  selector: 'app-admin-election-list',
  templateUrl: './admin-election-list.component.html',
  styleUrls: ['./admin-election-list.component.css']
})
export class AdminElectionListComponent implements OnInit {
  list:any;
  checkele:any;
  val:boolean=true;
  constructor(private router:Router, private adminService:AdminServiceService, private constService:ConstituencyService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
    this.adminService.getElections().subscribe(data=>{this.list=data});
  }

  delete(element:any){
    this.list.forEach((value:any) => {
      if(value===element){
        this.adminService.deleteElection(value).subscribe(data=>{this.checkele=data});
        alert("Election deleted!!")
        this.adminService.getElections().subscribe(data=>{this.list=data});
        this.router.navigate(['election/list']);
      }
    });
  }

  add(element:any){
    this.list.forEach((value:any)=>{
      if(value===element){
        this.adminService.ep.election=value;
        this.val=false;
        this.router.navigate(['ep/add'])
      }
    })
  }

  redirect(){
    this.router.navigate(['/election/add']);
  }
}
