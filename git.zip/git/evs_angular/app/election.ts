export class Election {
    constructor(){}
    electionId:number|undefined;
    constituency:string|undefined;
    dateTime:Date|undefined;
}
