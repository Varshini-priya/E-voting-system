import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-login-form',
  templateUrl: './user-login-form.component.html',
  styleUrls: ['./user-login-form.component.css']
})
export class UserLoginFormComponent implements OnInit {
  user:User=new User();
  user2:any;
  public showPasswordOnPress: boolean =false;
  pass='password';
  show = false;
  
  constructor(private router: Router,private userService:UserServiceService) { }

  ngOnInit(): void {
    if(this.userService.user!=undefined){
      this.router.navigate(["/userHome"]);
    }
  }


  login(){
    let resp=this.userService.login(this.user);
    resp.subscribe(data=>{this.user2=data});
    this.userService.user=this.user2;
    if (this.user2===null || this.user2===undefined){
      alert("please check your credentials!!");
    }else{
      this.goToUserHome();
    }
  }

  goToUserHome(){
    this.router.navigate(['/userHome']);
  }

  onClick() {
    if (this.pass === 'password') {
      this.pass = 'text';
      this.show = true;
    } else {
      this.pass = 'password';
      this.show = false;
    }
  }
}
