import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminPartyAllComponent } from './admin-party-all.component';

describe('AdminPartyAllComponent', () => {
  let component: AdminPartyAllComponent;
  let fixture: ComponentFixture<AdminPartyAllComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminPartyAllComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminPartyAllComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
