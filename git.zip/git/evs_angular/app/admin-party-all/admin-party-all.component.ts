import { DOCUMENT } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Party } from '../party';

@Component({
  selector: 'app-admin-party-all',
  templateUrl: './admin-party-all.component.html',
  styleUrls: ['./admin-party-all.component.css']
})
export class AdminPartyAllComponent implements OnInit {

  list:Party[]=[];
  party:Party|any=new Party();

  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {

    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }

    let rep=this.adminService.getAllParties();
    rep.subscribe(data=>{this.list=data});
  }
  
  delete(element:any){
    this.list.forEach((value:any)=>{
      if(value===element){
        let res=this.adminService.deleteParty(value);
        res.subscribe(data=>{this.party=data});
        alert("Party deleted!!")
        let rep=this.adminService.getAllParties();
        rep.subscribe(data=>{this.list=data});
        this.router.navigate(['/party/all']);
      }
    })
  }
  
}
