import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserListComponent } from './user-list/user-list.component';
import { UserFormComponent } from './user-form/user-form.component';
import { SqaFormComponent } from './sqa-form/sqa-form.component';
import { UserLoginFormComponent } from './user-login-form/user-login-form.component';
import { UserConfirmationComponent } from './user-confirmation/user-confirmation.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { HomeComponent } from './home/home.component';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminPartyComponent } from './admin-party/admin-party.component';
import { AdminPartyAddComponent } from './admin-party-add/admin-party-add.component';
import { AdminPartyAllComponent } from './admin-party-all/admin-party-all.component';
import { AdminParticipantPartySelectComponent } from './admin-participant-party-select/admin-participant-party-select.component';
import { AdminParticipantAllComponent } from './admin-participant-all/admin-participant-all.component';
import { AdminParticipantAddComponent } from './admin-participant-add/admin-participant-add.component';
import { AdminVoterComponent } from './admin-voter/admin-voter.component';
import { AdminVoterAddComponent } from './admin-voter-add/admin-voter-add.component';
import { AdminVoterListComponent } from './admin-voter-list/admin-voter-list.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AdminElectionComponent } from './admin-election/admin-election.component';
import { AdminElectionScheduleComponent } from './admin-election-schedule/admin-election-schedule.component';
import { AdminElectionListComponent } from './admin-election-list/admin-election-list.component';
import { AdminEpAddComponent } from './admin-ep-add/admin-ep-add.component';
import { UserElectionListComponent } from './user-election-list/user-election-list.component';
import { VoterLogin } from './voter-login';
import { UserVotingComponent } from './user-voting/user-voting.component';
import { UserThankingComponent } from './user-thanking/user-thanking.component';
import { UserResultsComponent } from './user-results/user-results.component';
import { UserVoterLoginComponent } from './user-voter-login/user-voter-login.component';
const routes: Routes = [
  {path:"", component:HomeComponent},
  {path:"sqa", component:SqaFormComponent},
  {path:"save", component:UserFormComponent},
  {path:"getAll", component:UserListComponent},
  {path:"login", component:UserLoginFormComponent},
  {path:"confirm", component:UserConfirmationComponent},
  {path:"userHome", component:UserHomeComponent},
  {path:"user/profile", component:UserProfileComponent},
  {path:"admin/login", component:AdminLoginComponent},
  {path:"adminHome", component:AdminHomeComponent},
  {path:"party", component:AdminPartyComponent},
  {path:"party/add", component:AdminPartyAddComponent},
  {path:"party/all", component:AdminPartyAllComponent},
  {path:"participant/party", component:AdminParticipantPartySelectComponent},
  {path:"participant/add", component:AdminParticipantAddComponent},
  {path:"participant/get", component:AdminParticipantAllComponent},
  {path:"voter-a", component:AdminVoterComponent},
  {path:"voter/add", component:AdminVoterAddComponent},
  {path:"voter/list", component:AdminVoterListComponent},
  {path:"forgotpass", component:ForgotPasswordComponent},
  {path:"changepass", component:ChangePasswordComponent},
  {path:"election", component:AdminElectionComponent},
  {path:"election/add", component:AdminElectionScheduleComponent},
  {path:"election/list", component:AdminElectionListComponent},
  {path:"ep/add", component:AdminEpAddComponent},
  {path:"election/user", component:UserElectionListComponent},
  {path:"voter/login", component:UserVoterLoginComponent},
  {path:"voting", component:UserVotingComponent},
  {path:"thank", component:UserThankingComponent},
  {path:"result", component:UserResultsComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
