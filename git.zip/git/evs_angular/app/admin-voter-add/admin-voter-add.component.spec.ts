import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminVoterAddComponent } from './admin-voter-add.component';

describe('AdminVoterAddComponent', () => {
  let component: AdminVoterAddComponent;
  let fixture: ComponentFixture<AdminVoterAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminVoterAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminVoterAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
