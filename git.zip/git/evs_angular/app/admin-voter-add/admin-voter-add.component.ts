import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Voter } from '../voter';

@Component({
  selector: 'app-admin-voter-add',
  templateUrl: './admin-voter-add.component.html',
  styleUrls: ['./admin-voter-add.component.css']
})
export class AdminVoterAddComponent implements OnInit {
  voter:Voter=new Voter();
  checkVoter:any;
  error:string='';
  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
  }

  check(){
    this.adminService.getVoterByVoterId(this.voter.voterId).subscribe(data=>{this.checkVoter=data});
    if (this.checkVoter==null || !this.checkVoter){
      this.add();
    }else{
      this.errors();
    }
  }

  add(){
    this.voter.status="false";
    this.adminService.addVoter(this.voter).subscribe(data=>{this.checkVoter=data});
    alert("Voter added");
    this.router.navigate(["voter/list"]);
  }

  errors(){
    this.error="Check the details again!";
    this.router.navigate(['voter/add']);
  }
}
