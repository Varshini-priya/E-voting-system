import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminParticipantAddComponent } from './admin-participant-add.component';

describe('AdminParticipantAddComponent', () => {
  let component: AdminParticipantAddComponent;
  let fixture: ComponentFixture<AdminParticipantAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminParticipantAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdminParticipantAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
