import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';
import { Participant } from '../participant';

@Component({
  selector: 'app-admin-participant-add',
  templateUrl: './admin-participant-add.component.html',
  styleUrls: ['./admin-participant-add.component.css']
})
export class AdminParticipantAddComponent implements OnInit {

  participant:Participant=new Participant();
  checkPt:any; error:string='';

  constructor(private router:Router, private adminService:AdminServiceService) { }

  ngOnInit(): void {
    if(this.adminService.admin===undefined||this.adminService.admin===null){
      this.router.navigate(["admin/login"]);
    }
  }

  check(){
    let resp=this.adminService.getParticipantByName(this.participant);
    resp.subscribe(data=>{this.checkPt=data});
    if(this.checkPt===null){
      this.add();
    }else{
      this.errors();
    }
  }

  add(){
    this.participant.party=this.adminService.participant.party;
    this.adminService.saveParticipant(this.participant).subscribe(data=>{this.checkPt=data});
    alert("Participant saved");
    this.router.navigate(['participant/get']);
  }

  errors(){
    this.error="Participant already exits!!";
    this.router.navigate(['/participant/add']);
  }
}
