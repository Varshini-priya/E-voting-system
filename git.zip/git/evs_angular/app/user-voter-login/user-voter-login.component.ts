import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';
import { Voter } from '../voter';
import { VoterLogin } from '../voter-login';

@Component({
  selector: 'app-user-voter-login',
  templateUrl: './user-voter-login.component.html',
  styleUrls: ['./user-voter-login.component.css']
})
export class UserVoterLoginComponent implements OnInit {
  user:User=new User();
  voterLogin:VoterLogin=new VoterLogin();
  checkele:any;
  voter:Voter=new Voter();
  constructor(private router:Router, private userService:UserServiceService) { }

  ngOnInit(): void {
  }

  check(){
    this.userService.checkVoter(this.voterLogin).subscribe(data=>{this.checkele=data})
    if(!this.checkele||this.checkele===null){
      alert("Check credentials!!");
    }else{
      this.userService.voter.voterId=this.voterLogin.voterId;
      this.router.navigate(['/voting']);
    }
  }
}
