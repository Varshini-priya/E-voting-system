import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserVoterLoginComponent } from './user-voter-login.component';

describe('UserVoterLoginComponent', () => {
  let component: UserVoterLoginComponent;
  let fixture: ComponentFixture<UserVoterLoginComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserVoterLoginComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserVoterLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
