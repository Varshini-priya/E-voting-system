export class User {
    constructor(){
        
    }
    userId:number | undefined ;
    name:string | undefined ;
    dateOfBirth:Date | undefined ;
    phoneNo:number | undefined ;
    address:string | undefined ;
    constituency:String|null=null;
    password:string | undefined ;
    /*
    
    constructor(userId:number,name:string,dateOfBirth:Date,phoneNo:number,address:string,constituency:String,password:string){
        this.userId=userId;
        this.name=name;
        this.dateOfBirth=dateOfBirth;
        this.phoneNo=phoneNo;
        this.address=address;
        this.constituency=constituency;
        this.password=password;
    }
    */
}
