import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {
  password1:any;
  password:any;
  user:any
  constructor(private router:Router, private userService:UserServiceService) { }

  ngOnInit(): void {
    if(this.userService.user===undefined||this.userService.user===null){
      this.router.navigate(["/login"])
    }
  }

  change(){
    if(this.password===this.password1){
      this.go();
    }
    else{
      alert("Passwords doesn't match!!");
    }
  }

  go(){
      this.userService.user.password=this.password;
      this.userService.changePass(this.userService.user).subscribe(data=>{this.user=data});
      alert("Password changed!!");
      this.userService.user=undefined;
      this.router.navigate(['/login']);
  }
}
