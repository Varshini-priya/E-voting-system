export class Admin {
    constructor(){

    }
    username:string | undefined;
    password:string | undefined;
}
