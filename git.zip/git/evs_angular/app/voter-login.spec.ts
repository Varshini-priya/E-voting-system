import { VoterLogin } from './voter-login';

describe('VoterLogin', () => {
  it('should create an instance', () => {
    expect(new VoterLogin()).toBeTruthy();
  });
});
