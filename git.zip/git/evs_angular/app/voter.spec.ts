import { Voter } from './voter';

describe('Voter', () => {
  it('should create an instance', () => {
    expect(new Voter()).toBeTruthy();
  });
});
