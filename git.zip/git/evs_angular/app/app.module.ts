import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { BrowserModule } from '@angular/platform-browser';
import { UserServiceService } from './user-service.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { UserListComponent } from './user-list/user-list.component';
import { UserFormComponent } from './user-form/user-form.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { SqaFormComponent } from './sqa-form/sqa-form.component';
import { SqaListComponent } from './sqa-list/sqa-list.component';
import { UserLoginFormComponent } from './user-login-form/user-login-form.component';
import { UserConfirmationComponent } from './user-confirmation/user-confirmation.component';
import { UserHomeComponent } from './user-home/user-home.component';
import { HomeComponent } from './home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { AdminPartyComponent } from './admin-party/admin-party.component';
import { AdminPartyAddComponent } from './admin-party-add/admin-party-add.component';
import { AdminVoterComponent } from './admin-voter/admin-voter.component';
import { AdminVoterAddComponent } from './admin-voter-add/admin-voter-add.component';
import { AdminPartyAllComponent } from './admin-party-all/admin-party-all.component';
import { AdminParticipantAddComponent } from './admin-participant-add/admin-participant-add.component';
import { AdminParticipantAllComponent } from './admin-participant-all/admin-participant-all.component';
import { AdminParticipantPartySelectComponent } from './admin-participant-party-select/admin-participant-party-select.component';
import { AdminVoterListComponent } from './admin-voter-list/admin-voter-list.component';
import { UserVoterLoginComponent } from './user-voter-login/user-voter-login.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { AdminElectionComponent } from './admin-election/admin-election.component';
import { AdminElectionScheduleComponent } from './admin-election-schedule/admin-election-schedule.component';
import { AdminElectionListComponent } from './admin-election-list/admin-election-list.component';
import { AdminEpAddComponent } from './admin-ep-add/admin-ep-add.component';
import { UserElectionListComponent } from './user-election-list/user-election-list.component';
import { UserVotingComponent } from './user-voting/user-voting.component';
import { UserThankingComponent } from './user-thanking/user-thanking.component';
import { UserResultsComponent } from './user-results/user-results.component';

@NgModule({
  declarations: [
    AppComponent,
    UserListComponent,
    UserFormComponent,
    SqaFormComponent,
    SqaListComponent,
    UserLoginFormComponent,
    UserConfirmationComponent,
    UserHomeComponent,
    HomeComponent,
    UserProfileComponent,
    AdminLoginComponent,
    AdminHomeComponent,
    AdminPartyComponent,
    AdminPartyAddComponent,
    AdminVoterComponent,
    AdminVoterAddComponent,
    AdminPartyAllComponent,
    AdminParticipantAddComponent,
    AdminParticipantAllComponent,
    AdminParticipantPartySelectComponent,
    AdminVoterListComponent,
    UserVoterLoginComponent,
    ForgotPasswordComponent,
    ChangePasswordComponent,
    AdminElectionComponent,
    AdminElectionScheduleComponent,
    AdminElectionListComponent,
    AdminEpAddComponent,
    UserElectionListComponent,
    UserVotingComponent,
    UserThankingComponent,
    UserResultsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule, 
    FormsModule, 
    ReactiveFormsModule, 
    BrowserAnimationsModule,
    MatButtonModule
  ],
  providers: [UserServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
