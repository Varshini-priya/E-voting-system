import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user-thanking',
  templateUrl: './user-thanking.component.html',
  styleUrls: ['./user-thanking.component.css']
})
export class UserThankingComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  home(){
    this.router.navigate(['userHome']);
  }

}
