import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UserThankingComponent } from './user-thanking.component';

describe('UserThankingComponent', () => {
  let component: UserThankingComponent;
  let fixture: ComponentFixture<UserThankingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UserThankingComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UserThankingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
