import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserServiceService } from '../user-service.service';

@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.css']
})
export class UserProfileComponent implements OnInit {

  constructor(private router:Router, private userService:UserServiceService) { }

  ngOnInit(): void {
    if(this.userService.user===undefined||this.userService.user===null){
      this.router.navigate(["/login"])
    }
  }
  user:User=this.userService.user;

  redirect(){
    this.router.navigate(['/changepass']);
  }
}
