export class Party {
    constructor(){}

    partyId:number | undefined;
    partyName:string | undefined;
    constituency:string | any=null;
}
