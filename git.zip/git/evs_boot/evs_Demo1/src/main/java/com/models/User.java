package com.models;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="\"user\"")
public class User {
	@Id
	@Column(name="user_id")
	@GeneratedValue(generator="userid_seq")
	private long userId;
	@Column(name="name")
	private String name;
	@Column(name="date_of_birth")
	private Date dateOfBirth;
	@Column(name="phone_no")
	private long phoneNo;
	@Column(name="address")
	private String address;
	@Column(name="constituency")
	private String constituency;
	@Column(name="password")
	private String password;
	
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getConstituency() {
		return constituency;
	}
	public void setConstituency(String constituency) {
		this.constituency = constituency;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public User(String name, Date dateOfBirth, long phoneNo, String address, String constituency,String password) {
		super();
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.phoneNo = phoneNo;
		this.address = address;
		this.constituency = constituency;
		this.password = password;
	}
	
	public User(long userId, String name, Date dateOfBirth, long phoneNo, String address, String constituency,String password) {
		super();
		this.userId = userId;
		this.name = name;
		this.dateOfBirth = dateOfBirth;
		this.phoneNo = phoneNo;
		this.address = address;
		this.constituency = constituency;
		this.password = password;
	}
	
	public User(){}
	
}
