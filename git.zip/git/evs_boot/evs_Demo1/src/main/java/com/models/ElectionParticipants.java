package com.models;

import javax.persistence.*;

@Entity
@Table(name="election_participant")
public class ElectionParticipants {
	@Id
	@GeneratedValue(generator="EPid_seq")
	@Column(name="id")
	private int id;
	@Column(name="votes")
	private int noOfVote;
	@ManyToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="election_id")
	private Election election;
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="pid")
	private Participant participants;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getNoOfVote() {
		return noOfVote;
	}
	public void setNoOfVote(int noOfVote) {
		this.noOfVote = noOfVote;
	}
	public Election getElection() {
		return election;
	}
	public void setElection(Election election) {
		this.election = election;
	}
	public Participant getParticipants() {
		return participants;
	}
	public void setParticipants(Participant participants) {
		this.participants = participants;
	}
	
	public ElectionParticipants(int id, int noOfVote, Election election, Participant participants) {
		super();
		this.id = id;
		this.noOfVote = noOfVote;
		this.election = election;
		this.participants = participants;
	}
	
	public ElectionParticipants(int noOfVote, Election election, Participant participants) {
		super();
		this.noOfVote = noOfVote;
		this.election = election;
		this.participants = participants;
	}
	
	public ElectionParticipants(){}
}
