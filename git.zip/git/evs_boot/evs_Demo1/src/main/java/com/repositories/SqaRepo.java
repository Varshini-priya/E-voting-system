package com.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.models.SecurityQA;
import com.models.User;

@Transactional
public interface SqaRepo extends CrudRepository<SecurityQA, Integer> {
	List<SecurityQA> findByUser(User user);
}
