package com.models;

public class VoterLogin {
	long voterId;
	long userId;
	String password;
	public VoterLogin(long voterId, long userId, String password) {
		super();
		this.voterId = voterId;
		this.userId = userId;
		this.password = password;
	}
	public VoterLogin() {
		super();
	}
	public long getVoterId() {
		return voterId;
	}
	public void setVoterId(long voterId) {
		this.voterId = voterId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	};
	
	
}
