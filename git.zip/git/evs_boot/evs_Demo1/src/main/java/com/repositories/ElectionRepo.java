package com.repositories;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.repository.CrudRepository;

import com.models.*;

@Transactional
public interface ElectionRepo extends CrudRepository<Election, Long> {
	List<Election> findAllByOrderByElectionIdAsc();
	List<Election> findAllByOrderByElectionIdDesc();
	List<Election> findByElectionId(long electionId);
	List<Election> findByDateTime(Date dateTime);
	long findElectionIdByDateTime(Date date);
}
