package com.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.models.Party;

@Transactional
public interface PartyRepo extends CrudRepository<Party, Long> {
	List<Party> findByPartyName(String partyName);
	List<Party> findByPartyId(long partyId);
	List<Party> findAllByOrderByPartyIdAsc();
	@Query("from Party p where p.constituency=:constituency")
	List<Party> findByConstituency(String constituency);
}
