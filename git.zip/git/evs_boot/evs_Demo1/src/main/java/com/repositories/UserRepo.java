package com.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Repository;

import com.models.User;

@Transactional
public interface UserRepo extends CrudRepository<User, Long> {
	List<User> findByPhoneNo(long phoneNo);
	List<User> findByUserId(long userId);
	List<User> findAllByOrderByUserIdAsc();
	@Modifying
	@Query("update User u set u.password=:password where u.userId=:userId")
	void updatePassword(String password, long userId);
}
