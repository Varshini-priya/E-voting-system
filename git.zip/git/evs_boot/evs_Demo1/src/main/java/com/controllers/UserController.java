package com.controllers;

import java.util.*;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.models.*;
import com.repositories.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/evs")
@Transactional
public class UserController {
	@Autowired
	UserRepo uRepo;
	@Autowired
	SqaRepo sqaRepo;
	User u;
	
	@PostMapping("/getUser")									//Get user by phoneNo
	public User getUser(@RequestBody User user) {
		List<User> list=uRepo.findByPhoneNo(user.getPhoneNo());
		if(list.size()==0||list==null) {
			return null;
		}
		return list.get(0);
	}
	
	@PostMapping("/addUsers")									//User register method
    public User addUser(@RequestBody User user) {
		uRepo.save(user);
		this.u=uRepo.findByPhoneNo(user.getPhoneNo()).get(0);
		return u;	
    }
	
	@PostMapping("/sqa")										//Add a security question and answer after registering
	public SecurityQA setSecQA(@RequestBody SecurityQA sqa){
		sqa.setUser(this.u);
		sqaRepo.save(sqa);
		return sqa;
		
	}
	
	@PostMapping("/login")										//User login with userId and password
	public User userLogin(@RequestBody User user){
		User user1=uRepo.findByUserId(user.getUserId()).get(0);
		if (user1==null){
			return null;
		}
		else if(!user1.getPassword().equals(user.getPassword())){
			return null;
		}
		return user1;
	}
	
	@PostMapping("/getSqa")										//Get security question and answer ==> forgot password
	public SecurityQA getSqa(@RequestBody User user) {
		List<User> list=uRepo.findByUserId(user.getUserId());
		if(list.size()==0||list==null) {
			return null;
		}
		SecurityQA sqa=sqaRepo.findByUser(list.get(0)).get(0);
		return sqa;
	}
	
	@PostMapping("/changepass")									//Change password of a user
	public User changePass(@RequestBody User user) {
		uRepo.updatePassword(user.getPassword(), user.getUserId());
		User u=uRepo.findByUserId(user.getUserId()).get(0);
		return u;
	}
	
}
