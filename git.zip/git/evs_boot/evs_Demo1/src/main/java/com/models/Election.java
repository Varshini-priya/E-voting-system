package com.models;

import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name="elections")
public class Election {
	@Id
	@GeneratedValue(generator="electionid_seq")
	private long electionId;
	@Column(name="constituency")
	private String constituency;
	@Column(name="date_time")
	private Date dateTime;
	
	public long getElectionId() {
		return electionId;
	}
	public void setElectionId(long electionId) {
		this.electionId = electionId;
	}
	public String getConstituency() {
		return constituency;
	}
	public void setConstituency(String constituency) {
		this.constituency = constituency;
	}
	public Date getDateTime() {
		return dateTime;
	}
	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}
	
	public Election(long electionId, String constituency, Date dateTime) {
		super();
		this.electionId = electionId;
		this.constituency = constituency;
		this.dateTime = dateTime;
	}
	public Election() {
		super();
	}
}
