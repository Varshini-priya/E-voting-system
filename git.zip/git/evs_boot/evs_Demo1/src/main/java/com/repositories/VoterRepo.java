package com.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.models.Voter;

public interface VoterRepo extends CrudRepository<Voter, Long> {
	List<Voter> findAllByOrderByVoterIdAsc();
	List<Voter> findByVoterId(long voterId);
	@Modifying
	@Query("update Voter v set v.status='false'")
	void updateAllByStatus();
	@Modifying
	@Query("update Voter v set v.status='true' where v.voterId=:voterId")
	Voter updateVoterByVoterId(long voterId);
}
