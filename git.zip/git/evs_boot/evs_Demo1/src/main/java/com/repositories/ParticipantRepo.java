package com.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.models.*;

@Transactional
public interface ParticipantRepo extends CrudRepository<Participant, Long> {
	List<Participant> findAllByOrderByParticipantIdAsc();
	List<Participant> findByParticipantName(String participantName);
	List<Participant> findByParty(Party party);
	List<Participant> findByParticipantId(long participantId);
	Participant deleteByParticipantName(String participantName);
	@Query("from Participant p where party in (from Party p where p.constituency=:constituency)")
	List<Participant> get(String constituency);
}
