package com.models;

import javax.persistence.*;

@Entity
@Table(name="party")
public class Party {
	@Id
	@GeneratedValue(generator="partyid_seq")
	@Column(name="party_id")
	private long partyId;
	@Column(name="party_name")
	private String partyName;
	@Column(name="constituency")
	private String constituency;
	
	public long getPartyId() {
		return partyId;
	}
	public void setPartyId(long partyId) {
		this.partyId = partyId;
	}
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	public String getConstituency() {
		return constituency;
	}
	public void setConstituency(String constituency) {
		this.constituency = constituency;
	}
	
	public Party(long partyId, String partyName, String constituency) {
		super();
		this.partyId = partyId;
		this.partyName = partyName;
		this.constituency = constituency;
	}
	
	public Party() {
		super();
	}
}
