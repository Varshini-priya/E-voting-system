package com.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.models.*;
import com.repositories.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/evs/admin")
@Transactional
public class AdminController {
	@Autowired
	UserRepo uRepo;
	@Autowired
	PartyRepo pRepo;
	@Autowired
	ParticipantRepo ptRepo;
	@Autowired
	VoterRepo vRepo;
	@Autowired
	ElectionRepo eRepo;
	@Autowired
	ElectionParticipantsRepo epRepo;
	
	@PostMapping("/login")								//Admin credentials check
	public Admin adminLogin(@RequestBody Admin admin){
		if ("ADMIN".equalsIgnoreCase(admin.getUsername())&&"ADMIN".equals(admin.getPassword())){
			return admin;
		}
		return null;
	}
	
	@GetMapping("/users")								//Get all user's details
    public List<User> getUsers() {
		List<User> list=new ArrayList<User>();
		uRepo.findAllByOrderByUserIdAsc().forEach(list::add);
        return list;
    }
	
	@PostMapping("/party/get")							//Get party details by name
	public Party getParty(@RequestBody Party party) {
		List<Party> p=pRepo.findByPartyName(party.getPartyName().toUpperCase());
		if (p.size()==0||p==null) {
			return null;
		}
		return p.get(0);
	}
	
	@PostMapping("/party/add")							//Insert new party details
	public Party addParty(@RequestBody Party party) {
		//Party p=pRepo.findByPartyName(party.getPartyName()).get(0);
		party.setPartyName(party.getPartyName().toUpperCase());
		return pRepo.save(party);
	}
	
	@GetMapping("/party/getAll")						//Get all party details
	public List<Party> getAllParty(){
		List<Party> list=new ArrayList<Party>();
		pRepo.findAllByOrderByPartyIdAsc().forEach(list::add);
        return list;
	}
	
	@PostMapping("/party/delete")						//Delete party details
	public Party deleteParty(@RequestBody Party party) {
		Party p=pRepo.findByPartyId(party.getPartyId()).get(0);
		pRepo.delete(p);
		return p;
	}
	
	@PostMapping("/participant/get")					//Get single participant details
	public Participant getParticipant(@RequestBody Participant participant) {
		List<Participant> list=ptRepo.findByParticipantName(participant.getParticipantName());
		if (list.size()==0 || list==null) {
			return null;
		}
		return list.get(0);
	}
	
	@PostMapping("/participant/add")					//Add participant details
	@Transactional
	public Participant addParticipant(@RequestBody Participant participant) {
		ptRepo.save(participant);
		Participant p=ptRepo.findByParticipantName(participant.getParticipantName()).get(0);
		return p;
	}
	
	@PostMapping("/participant/get/party")				//Get all participants in a party
	public List<Participant> getParticipantList(@RequestBody Party party){
		List<Participant> list=new ArrayList<Participant>();
		ptRepo.findByParty(party).forEach(list::add);
		if(list==null || list.size()==0) {
			return null;
		}
		return list;
	}
	
	@PostMapping("/participant/delete")					//Delete participant
	public Participant deleteParticipant(@RequestBody Participant participant) {
		Participant p=ptRepo.findByParticipantName(participant.getParticipantName()).get(0);
		ptRepo.delete(p);
		return p;
	}
	
	@PostMapping("/voter/add")							//Add voter details
	public Voter saveVoter(@RequestBody Voter voter) {
		return vRepo.save(voter);
	}
	
	@PostMapping("/voter/check")						//Voter credentials check
	public Voter checkVoter(@RequestBody VoterLogin vl) {
		Voter v=vRepo.findByVoterId(vl.getVoterId()).get(0);
		User u=uRepo.findByUserId(vl.getUserId()).get(0);
		if((u.getName().equalsIgnoreCase(v.getName()))&&(u.getPassword().equals(vl.getPassword()))&&(u.getPhoneNo()==v.getPhoneNo())) {
			return v;
		}
		return null;
	}
	
	@GetMapping("/voter/status")						//Update all voter status to normal
	public List<Voter> updateStatus() {
		vRepo.updateAllByStatus();
		return vRepo.findAllByOrderByVoterIdAsc();
	}
	
	@PostMapping("get/voter")							//Get voter 
	public Voter getVoter(@RequestBody Voter voter) {
		return vRepo.findByVoterId(voter.getVoterId()).get(0);
	}
	
	@PostMapping("/voter/update")						//Updated status after vote
	public Voter afterVote(@RequestBody Voter voter) {
		voter.setStatus("true");
		return vRepo.updateVoterByVoterId(voter.getVoterId());
	}
	
	@PostMapping("/voter/delete")						//Delete voter details
	public Voter deleteVoter(@RequestBody Voter voter) {
		Voter v=vRepo.findByVoterId(voter.getVoterId()).get(0);
		vRepo.delete(voter);
		return v;
	}
	
	@GetMapping("/voter/get")							//Get list of voters
	public List<Voter> getAllVoter(){
		return vRepo.findAllByOrderByVoterIdAsc();
	}
	
	@PostMapping("/voter/getOne")						//Get voter by voter Id
	public Voter getVoter(@RequestBody long voterId ){
		List<Voter> list=vRepo.findByVoterId(voterId);
		if(list==null||list.size()==0) {
			return null;
		}
		return list.get(0);
	}
	
	@PostMapping("election/add")						//Create election
	public Election addElection(@RequestBody Election election) {
		eRepo.save(election);
		return eRepo.findByDateTime(election.getDateTime()).get(0);
	}
	
	@PostMapping("election/get")						//Get election by date
	public Election getElection(@RequestBody Election election) {
		List<Election> list=eRepo.findByDateTime(election.getDateTime());
		if(list==null||list.size()==0) {
			return null;
		}
		return list.get(0);
	}
	
	@PostMapping("election/id")							//Get election by Id
	public Election getElectionById(@RequestBody Election election) {
		List<Election> list=eRepo.findByElectionId(election.getElectionId());
		if(list==null||list.size()==0) {
			return null;
		}
		return list.get(0);
	}
	
	@GetMapping("election/list")						//Get all elections
	public List<Election> getElections() {
		return eRepo.findAllByOrderByElectionIdAsc();
	}
	
	@PostMapping("election/delete")						//Delete election
	public Election deleteElection(@RequestBody Election election){
		Election e=eRepo.findByElectionId(election.getElectionId()).get(0);
		epRepo.deleteByElection(election);
		eRepo.delete(election);
		return e;
	}
	
	@PostMapping("ep/add")								//Save participants
	public ElectionParticipants addElectionParticipants(@RequestBody ElectionParticipants ep) {
		epRepo.save(ep);
		ElectionParticipants ep1=epRepo.findByParticipants(ep.getParticipants());
		return ep1;
	}
	
	@PostMapping("ep/get")								//Get participants by election
	public List<Participant> getParticipantsElection(@RequestBody Election election){
		return epRepo.findParticpantsByElection(election);
	}

	@PostMapping("participant/ep")						//Get participants by constituency
	public List<Participant> getParticipantsByConstituency(@RequestBody Election election){
		return ptRepo.get(election.getConstituency());
	}
	
	@PostMapping("participant/update")					//Update noOfVotes
	public ElectionParticipants updateParticipant(@RequestBody Participant p) {
		ElectionParticipants ep=epRepo.findByParticipants(p);
		int vote=epRepo.findNoOfVoteById(ep);
		vote++;
		epRepo.updateNoOfVotes(vote);
		return epRepo.findByParticipants(p);
	}
	
	@PostMapping("eps/get")								//Get election participants
	public List<ElectionParticipants> getEp(@RequestBody Election election){
		return epRepo.findByElectionOrderByIdAsc(election);
	}
}
