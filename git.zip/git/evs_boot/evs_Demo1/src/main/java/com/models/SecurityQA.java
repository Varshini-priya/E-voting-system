package com.models;

import javax.persistence.*;

@Entity
@Table(name="securityQA")
public class SecurityQA {
	@Id
	@GeneratedValue(generator="sqaid_seq")
	@Column(name="sqa_id")
	private int sqaId;
	@Column(name="question")
	private String question;
	@Column(name="answer")
	private String answer;
	@OneToOne(cascade = CascadeType.MERGE)
	@JoinColumn(name="user_id")
	private User user;
	
	public int getSqaId() {
		return sqaId;
	}
	public void setSqaId(int sqaId) {
		this.sqaId = sqaId;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	
	
	public SecurityQA(int sqaId, String question, String answer, User user) {
		super();
		this.sqaId = sqaId;
		this.question = question;
		this.answer = answer;
		this.user = user;
	}
	public SecurityQA(String question, String answer, User user) {
		super();
		this.question = question;
		this.answer = answer;
		this.user = user;
	}
	
	public SecurityQA(){}
}