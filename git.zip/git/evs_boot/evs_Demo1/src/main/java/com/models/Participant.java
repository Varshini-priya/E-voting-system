package com.models;
import javax.persistence.*;

@Entity
@Table(name="participant")
public class Participant {
	@Id
	@Column(name="pid")
	@GeneratedValue(generator="pid_seq")
	private long participantId;
	@Column(name="p_name")
	private String participantName;
	@OneToOne(cascade= CascadeType.MERGE)
	@JoinColumn(name="party_id")
	private Party party;
	
	public long getParticipantId() {
		return participantId;
	}

	public void setParticipantId(long participantId) {
		this.participantId = participantId;
	}

	public String getParticipantName() {
		return participantName;
	}

	public void setParticipantName(String participantName) {
		this.participantName = participantName;
	}

	public Party getParty() {
		return party;
	}

	public void setParty(Party party) {
		this.party = party;
	}

	public Participant(long participantId, String participantName, Party party) {
		super();
		this.participantId = participantId;
		this.participantName = participantName;
		this.party = party;
	}

	public Participant(){}
}
