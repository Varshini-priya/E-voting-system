package com.models;

import javax.persistence.*;

@Entity
@Table(name="voter")
public class Voter {
	@Id
	@Column(name="voter_id")
	private long voterId;
	@Column(name="name")
	private String name;
	@Column(name="phone_number")
	private long phoneNo;
	@Column(name="status")
	private String status;
	
	public long getVoterId() {
		return voterId;
	}
	public void setVoterId(long voterId) {
		this.voterId = voterId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Voter(long voterId, String name, long phoneNo, String status) {
		super();
		this.voterId = voterId;
		this.name = name;
		this.phoneNo = phoneNo;
		this.status = status;
	}
	public Voter(){}
}
