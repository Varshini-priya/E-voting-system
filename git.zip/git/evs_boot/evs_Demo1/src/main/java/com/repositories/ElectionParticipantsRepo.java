package com.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.models.*;

@Transactional
public interface ElectionParticipantsRepo extends CrudRepository<ElectionParticipants, Integer> {
	List<ElectionParticipants> findByElectionOrderByIdAsc(Election election);
	List<ElectionParticipants> deleteByElection(Election election);
	ElectionParticipants findByParticipants(Participant participant);
	List<Participant> findParticpantsByElection(Election election);
	@Query("update ElectionParticipants ep set ep.noOfVote=:noOfVote")
	void updateNoOfVotes(int noOfVote);
	int findNoOfVoteById(ElectionParticipants ep);
}
